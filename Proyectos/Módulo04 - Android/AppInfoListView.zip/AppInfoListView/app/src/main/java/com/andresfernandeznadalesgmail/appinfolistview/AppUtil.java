package com.andresfernandeznadalesgmail.appinfolistview;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class AppUtil {

    public static List<Permisos> todosPermisos(Context ctx){
        PackageManager pm = ctx.getPackageManager();
        CharSequence csPermissionGroupLabel;
        CharSequence csPermissionLabel;
        List<PermissionGroupInfo> lstGroups = pm.getAllPermissionGroups(0);
        List<Permisos> permisos = new ArrayList<>();
        for (PermissionGroupInfo pgi : lstGroups) {
            csPermissionGroupLabel = pgi.loadLabel(pm);
            Log.e("perm", pgi.name + ": " + csPermissionGroupLabel.toString());
            try {
                List<PermissionInfo> lstPermissions = pm.queryPermissionsByGroup(pgi.name, 0);
                for (PermissionInfo pi : lstPermissions) {
                    csPermissionLabel = pi.loadLabel(pm);
                    permisos.add(new Permisos(pi.name, csPermissionLabel.toString()));
                    Log.e("perm", " " + pi.name + ": " + csPermissionLabel.toString());
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return permisos;
    }
}
