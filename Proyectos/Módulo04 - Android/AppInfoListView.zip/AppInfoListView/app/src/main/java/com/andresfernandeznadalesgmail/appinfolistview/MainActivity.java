package com.andresfernandeznadalesgmail.appinfolistview;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.io.Serializable;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Permisos> permisos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        permisos = AppUtil.todosPermisos(this);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btnSpinner) {
            Intent intent = new Intent(this, PermisosSpinnerActivity.class);
            intent.putExtra("listPerm", (Serializable) permisos);
            startActivityForResult(intent, 1);
        } else if (v.getId() == R.id.btnListView) {
            Intent intent = new Intent(this, PermisosListViewActivity.class);
            intent.putExtra("listPerm", (Serializable) permisos);
            startActivityForResult(intent, 2);
        }
    }
}
