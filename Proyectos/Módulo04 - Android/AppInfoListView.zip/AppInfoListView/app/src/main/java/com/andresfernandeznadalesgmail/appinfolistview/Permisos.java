package com.andresfernandeznadalesgmail.appinfolistview;

import java.io.Serializable;
import java.util.regex.Pattern;

public class Permisos implements Serializable {
    private String name;
    private String descripcion;
    public Permisos (String namep, String descripcionp){
        name = namep;
        descripcion = descripcionp;
    }
    public String getName (){
        return name;
    }
    public String getDescripcion (){
        return descripcion;
    }
    public String toString (){
        String [] valores = name.split(Pattern.quote("."));
        return valores[valores.length - 1];
    }
}
