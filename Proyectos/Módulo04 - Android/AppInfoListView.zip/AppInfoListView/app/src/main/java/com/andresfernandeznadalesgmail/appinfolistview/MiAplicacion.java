package com.andresfernandeznadalesgmail.appinfolistview;

import android.app.Application;

public class MiAplicacion extends Application {

}
