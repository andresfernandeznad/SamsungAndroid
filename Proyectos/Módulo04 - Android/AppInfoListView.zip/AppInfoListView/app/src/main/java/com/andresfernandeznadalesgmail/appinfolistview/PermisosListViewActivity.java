package com.andresfernandeznadalesgmail.appinfolistview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class PermisosListViewActivity extends AppCompatActivity {

    List<Permisos> permisos;
    ListView lv;
    TextView desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);
        desc = findViewById(R.id.desc);Intent intent = getIntent();
        if (intent != null) {
            permisos = (List<Permisos>) intent.getSerializableExtra("listPerm");
        }
        //permisos = AppUtil.todosPermisos(this);
        lv = findViewById(R.id.list);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.item_listview, permisos);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                desc.setText(((Permisos)parent.getItemAtPosition(position)).getDescripcion());
            }
        });
    }
}
