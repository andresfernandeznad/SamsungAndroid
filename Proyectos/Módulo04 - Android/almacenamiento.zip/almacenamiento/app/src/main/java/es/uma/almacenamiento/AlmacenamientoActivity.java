package es.uma.almacenamiento;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AlmacenamientoActivity extends AppCompatActivity {
    /** Called when the activity is first created. */
	public static final String PREFS_NAME = "Almacenamiento";
    int recurso;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final EditText EdTxt=  (EditText) findViewById(R.id.editText1);
        Button botonLecRes=  (Button) findViewById(R.id.button1);
        Button botonGuardaSD=  (Button) findViewById(R.id.botonGuardaSD);
        Button botonLeerSD=  (Button) findViewById(R.id.botonLeerSD);
        final EditText editTextLeerSD=  (EditText) findViewById(R.id.editTextLeerSD);

		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        recurso = settings.getInt("lecturaRecurso", 0);

        botonLecRes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	try { 
                	StringBuffer txt= MostrartArchivo() ;
                	EdTxt.setText(txt);
                    recurso++;
                    Toast.makeText(getBaseContext(),"Lecturas: "+recurso, Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                	Log.d("Error lectura en Almacenamiento Interno",e.getMessage());
                	Toast.makeText(getBaseContext(),"Error lectura en Almacenamiento Interno: "+e.getMessage(), Toast.LENGTH_SHORT).show();
               }
            }	});
        
        botonGuardaSD.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

               if(isExternalStorageWritable())
            	try { 
                	String txt=EdTxt.getText().toString();
                	escribirSD(txt);
                } catch (IOException e) { 
                	Log.d("Error Escritura en Almacenamiento Externo",e.getMessage());
                	Toast.makeText(getBaseContext(),"Error Escritura  en Almacenamiento Externo: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                }
               else{
                   Toast.makeText(getBaseContext(),"Almacenamiento Externo no preparado. ", Toast.LENGTH_SHORT).show();
               }
            }	});
        
        botonLeerSD.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(isExternalStorageReadable())
                    try {
            		String txt= leerSD();
            		editTextLeerSD.setText(txt);
                } catch (IOException e) { 
                	Log.d("Error Lectura en Almacenamiento",e.getMessage());
                	Toast.makeText(getBaseContext(),"Error Lectura en Almacenamiento Externo: "+e.getMessage(), Toast.LENGTH_SHORT).show();
               }
                else{
                    Toast.makeText(getBaseContext(),"Almacenamiento Externo no preparado. ", Toast.LENGTH_SHORT).show();
                }
            }	});
    }
    
    
    public StringBuffer MostrartArchivo() throws IOException {
    	String str="";
	    StringBuffer buf = new StringBuffer(); 
	    InputStream is = this.getResources().openRawResource(R.raw.lapepa); 
	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(is)); 
	    
	    if (is!=null) 
	    	while ((str = reader.readLine()) != null) buf.append(str + "\n" );
	     is.close(); 
	 
	    return buf;
	}

    protected void onStop(){
        super.onStop();

        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("lecturaRecurso", recurso);

        editor.commit();
    }


    public void escribirSD(String info) throws IOException { 
    		String sdPath = Environment.getExternalStorageDirectory().getAbsolutePath() ;
    		File myFile = new File(sdPath+"/lapepa.txt"); 
    		myFile.createNewFile(); 
    		FileOutputStream fOut = new FileOutputStream(myFile); 
    		OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut); 
    		myOutWriter.append(info);
    		myOutWriter.close(); 
    		fOut.close(); 
    	
    	Toast.makeText(getBaseContext(),"Escritura en SD correcto.", Toast.LENGTH_SHORT).show();
    	
    }
    
    
    public String leerSD() throws IOException {
    	String sdPath = Environment.getExternalStorageDirectory().getAbsolutePath() ;
		File myFile = new File(sdPath+"/lapepa.txt"); 
		
    	FileInputStream fIn = new FileInputStream(myFile); 
    	BufferedReader myReader = new BufferedReader(new InputStreamReader(fIn)); 
    	String aDataRow = ""; String aBuffer = ""; 
    	while ((aDataRow = myReader.readLine()) != null) 
    		aBuffer += aDataRow + "\n";
    	 
    	myReader.close(); 
    	
    	Toast.makeText(getBaseContext(),"Lectura SD correcto", Toast.LENGTH_SHORT).show(); 
    	return aBuffer;
     }

    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }
}