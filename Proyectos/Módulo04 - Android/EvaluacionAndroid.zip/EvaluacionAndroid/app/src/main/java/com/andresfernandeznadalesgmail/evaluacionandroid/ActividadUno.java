package com.andresfernandeznadalesgmail.evaluacionandroid;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import io.michaelrocks.libphonenumber.android.*;

public class ActividadUno extends AppCompatActivity {

    public static final String DATOENTRADA = "DatoEntrada";
    private static final int PERMISO_LLAMADA = 1;

    EditText textoEntrada;
    String input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_uno);
        textoEntrada = findViewById(R.id.informacionEntrada);
    }

    public void onClick(View v) {
        input = textoEntrada.getText().toString();
        Log.d("ActividadUno:onClick", "El número es: " + input);
        if (input.isEmpty())
            Toast.makeText(getApplicationContext(), R.string.comprobacionVacio, Toast.LENGTH_SHORT).show();
        else {
            switch (v.getId()) {
                case R.id.botonCalcular:
                    Intent actividadDos = new Intent(this, ActividadDos.class);
                    actividadDos.putExtra(DATOENTRADA, input);
                    //startActivity(actividadDos);
                    startActivityForResult(actividadDos, 10); //Cuando termine la actividad que abro y me interesa el resultado.
                    Log.d("ActividadUno:onClick", "Continuo");
                    break;
                case R.id.botonLlamar:
                    llamar(); //Método donde se llama y todo eso
                    break;
            }
        }
    }

    private void llamar() {
        PhoneNumberUtil phoneUtil = PhoneNumberUtil.createInstance(getApplicationContext());
        Phonenumber.PhoneNumber number = null;
        try {
            number = phoneUtil.parse(input, "ES");
        } catch (NumberParseException e) {
            e.printStackTrace();
        }
        if (phoneUtil.isValidNumber(number)) {
            Intent llamar = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + input));
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) { //Pregunta si el permiso ya se ha dado.
                Log.d("Actividad.Uno:Permiso", "Error mensaje");

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CALL_PHONE},PERMISO_LLAMADA);
            } else startActivity(llamar);
        } else {
            Toast.makeText(getApplicationContext(),"No es un número de teléfono válido", Toast.LENGTH_SHORT).show();
        }
    }

    /*Cuando tu app solicita permisos, el sistema muestra al usuario un cuadro de diálogo.
    Cuando el usuario responde, el sistema invoca el método onRequestPermissionsResult()
    de tu app y le pasa la respuesta del usuario.
    Tu app debe anular ese método para averiguar si se otorgó el permiso.*/
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISO_LLAMADA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("Actividad:Call", "Permiso Concedido");
                    llamar();

                } else {
                    Log.d("Actividad:Call", "Permiso No Concedido");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
        }
    }

    //Recoge los datos al cargarse la actividad 2.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 10) {
            if (resultCode == RESULT_OK) {
                int div = data.getIntExtra("divisores", 0);
                if (div <= 2) Toast.makeText(getApplicationContext(), "Su número es primo", Toast.LENGTH_SHORT).show();
                else Toast.makeText(getApplicationContext(), "La cantidad de divisores del número son " + div, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
