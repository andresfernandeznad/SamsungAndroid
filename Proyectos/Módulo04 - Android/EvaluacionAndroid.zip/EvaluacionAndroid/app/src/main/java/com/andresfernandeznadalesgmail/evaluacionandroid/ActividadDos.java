package com.andresfernandeznadalesgmail.evaluacionandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class ActividadDos extends AppCompatActivity {

    int numero = 0;
    List<Integer> numeros = new ArrayList<>();
    TextView textView;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_dos);
        textView = findViewById(R.id.textoDatoActividad1);
        textView2 = findViewById(R.id.textoDivisores);
        //String valor = ActividadUno.DATOENTRADA;
        Intent intent = getIntent(); //Recoge el intent que me manda el número anterior
        if (intent != null) {
            numero = Integer.parseInt(intent.getStringExtra(ActividadUno.DATOENTRADA));
            Toast.makeText(this, "Valor enviado correctamente", Toast.LENGTH_LONG).show();
        }
        calcularDiv();
        textView.setText(numero + " ");
        textView2.setText(numeros.toString());
    }

    public void onClick(View v) {
        devolver();
        finish(); //Acabamos la actividad actual.
    }

    private void calcularDiv() {
        for (int i = 1; i <= numero; i++) {
            if (numero%i == 0) {
                numeros.add(i);
            }
        }
    }

    //Método donde ponemos los valores que devolvemos al matar la actividad o al darle a volver en el móvil.
    private void devolver(){
        Intent volver = getIntent(); //Cogemos el mismo intent para no tener que declarar otro.
        volver.putExtra("divisores", numeros.size());
        this.setResult(RESULT_OK, volver); //Le asignamos al setResult el intent que devolvemos con su código de si funciona o no
    }

    @Override
    public void onBackPressed() { //Cuando pulsa el botón de hacia detrás del teléfono.
        devolver();
        super.onBackPressed();
    }
}
