package es.uma.SQL;


import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class SQLActivity extends AppCompatActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Button botonAdd= (Button) findViewById(R.id.button2);
        final Button botonConsulta= (Button) findViewById(R.id.button1);
      
        final Intent IntentConsulta = new Intent(SQLActivity.this, Consulta.class);
        final Intent IntentAdd = new Intent(SQLActivity.this, AddAlumnos.class);
        
       
        
        botonAdd.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {

        	    startActivity(IntentConsulta);
        }
        });
        
        botonConsulta.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {

        	    startActivity(IntentAdd);
        }
        });
      
        
    }
    
    
}