package es.uma.SQL;

import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;

public class AdaptadorBD {

	public static final String KEY_ROWID = "_id";
	public static final String KEY_ALUMNO = "alumno";
	public static final String KEY_CURSO = "curso";
	public static final String KEY_TELEFONO = "telefono";
	
	private static final String TAG = "AdaptadorBD";
	
	private static final String DATABASE_NAME = "gestionCentros";
	private static final String DATABASE_TABLE = "Infoalumno";
	private static final int DATABASE_VERSION = 1;
	
	private static final String DATABASE_TABLE_CREATE =
	"create table "+DATABASE_TABLE+
	"("+KEY_ROWID+" integer primary key autoincrement, "
	+KEY_ALUMNO+" text not null, "
	+KEY_CURSO+" text not null, "
	+KEY_TELEFONO+" text not null);";
	
	private final Context context;
	
	
	private BaseDatosHelper BDHelper;
	private SQLiteDatabase bsSql;


	private String[] todasColumnas =new String[] {KEY_ROWID,KEY_ALUMNO,KEY_CURSO,KEY_TELEFONO};

	public AdaptadorBD(Context ctx) {
		this.context = ctx;
		BDHelper = new BaseDatosHelper(context);
	}
	
	public AdaptadorBD openEscritura() throws SQLException{
		bsSql = BDHelper.getWritableDatabase();
		return this;
	}

	public AdaptadorBD openLectura() throws SQLException{
		bsSql = BDHelper.getReadableDatabase();
		return this;
	}



	public void close(){

	    BDHelper.close();
	}
	
	public long insertarAlumno(String alumno, String curso, String telefono){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_ALUMNO, alumno);
		initialValues.put(KEY_CURSO, curso);
		initialValues.put(KEY_TELEFONO, telefono);
		return bsSql.insert(DATABASE_TABLE, null, initialValues);
	}
	
	public long insertarAlumno(Alumnos alumno){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_ALUMNO, alumno.getNombre());
		initialValues.put(KEY_CURSO, alumno.getCurso());
		initialValues.put(KEY_TELEFONO, alumno.getCurso());
		return bsSql.insert(DATABASE_TABLE, null, initialValues);
	}
	
	
	
	public boolean borrarAlumno(long expediente){
		return bsSql.delete(DATABASE_TABLE, KEY_ROWID + "=" + expediente, null) > 0;
	}
	
	
	public Cursor getTodosAlumnos() {
	
		return bsSql.query(DATABASE_TABLE, todasColumnas,null,null,null,null,null);
	}
	
	
	public Cursor getAlumno(long expediente) throws SQLException{
	
		Cursor mCursor = bsSql.query(true, DATABASE_TABLE, todasColumnas,
					KEY_ROWID + "=" + expediente,null,null,null,null,null);
		
		if (mCursor != null)  mCursor.moveToFirst();
	
		return mCursor;
	}
	
	
	
	
	public boolean actualizarAlumno(int expediente, String alumno, String curso, String telefono){
		ContentValues args = new ContentValues();
		args.put(KEY_ALUMNO, alumno);
		args.put(KEY_CURSO, curso);
		args.put(KEY_TELEFONO, telefono);
		return bsSql.update(DATABASE_TABLE, args,KEY_ROWID + "=" + expediente, null) > 0;
	}
	
	public boolean actualizarAlumno(Alumnos alumno){
		ContentValues args = new ContentValues();
		args.put(KEY_ALUMNO, alumno.getNombre());
		args.put(KEY_CURSO, alumno.getCurso());
		args.put(KEY_TELEFONO, alumno.getTelefono());
		return bsSql.update(DATABASE_TABLE, args,KEY_ROWID + "=" + alumno.getExpediente(), null) > 0;
	}
	
	public String MostrarAlumno(long expediente){
		String cadena=null;
		
		 Cursor c = getAlumno(expediente);
		 
		 if (c.moveToFirst()){

			 cadena= 
				"EXPEDIENTE: " + c.getString(0) + "\n" +
				"ALUMNO: " + c.getString(1) + "\n" +
				"CURSO: " + c.getString(2) + "\n" +
				"TELEFONO: " + c.getString(3);
		 }
		 
		return cadena;
	}
	
	public String MostrarAlumno(Cursor c){
		String cadena=null;
		
		 	 cadena= 
				"EXPEDIENTE: " + c.getString(0) + "\n" +
				"ALUMNO: " + c.getString(1) + "\n" +
				"CURSO: " + c.getString(2) + "\n" +
				"TELEFONO: " + c.getString(3);
		 
		return cadena;
	}
	
	public List<Alumnos> getAllAlumnos() {
		
		List<Alumnos> listaAlumnos = new ArrayList<Alumnos>();
		Cursor cursor = this.getTodosAlumnos();
				
				cursor.moveToFirst(); 
				
				while (!cursor.isAfterLast()) {
					Alumnos comment = cursorToAlumnos(cursor); 
					listaAlumnos.add(comment); 
					cursor.moveToNext();
				}
				cursor.close(); 
				return listaAlumnos;
				
	}
	
	private Alumnos cursorToAlumnos(Cursor cursor) { 
		Alumnos alumno = new Alumnos(); 
		alumno.setExpediente(cursor.getLong(0));
		alumno.setNombre(cursor.getString(1));
		alumno.setCurso(cursor.getString(2));
		alumno.setTelefono(cursor.getString(3));
		
		return alumno;
	}
	
	
//**** CLASE PRIVADA ***/	
	
	private static class BaseDatosHelper extends SQLiteOpenHelper{
		BaseDatosHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		@Override
		public void onCreate(SQLiteDatabase db)	{

		    db.execSQL(DATABASE_TABLE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion,int newVersion){
				Log.w(TAG, "Actualizando base de datos de la version " + oldVersion
				+ " a "
				+ newVersion + ", borraremos todos los datos");
				db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
				onCreate(db);
		}
	}

	
}
