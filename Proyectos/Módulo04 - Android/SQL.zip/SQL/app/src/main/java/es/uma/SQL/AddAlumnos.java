package es.uma.SQL;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

public class AddAlumnos extends Activity {
	  EditText edAlumno;
      EditText edTlf;

	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.addalumnos);
	        
	        
	        final Spinner s = (Spinner) findViewById(R.id.spinnerAdd);
	        edAlumno = (EditText) findViewById(R.id.editTextAlumno);
	        edTlf = (EditText) findViewById(R.id.editTextTelefono);

	        
	        
	        ArrayAdapter adapter = ArrayAdapter.createFromResource(
	        					this, R.array.cursos, android.R.layout.simple_spinner_item);
	        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	        s.setAdapter(adapter);
	        
	        
	        final Button botonAdd= (Button) findViewById(R.id.AddAlumnoBoton);
	      
	       
	        
	        botonAdd.setOnClickListener(new ImageButton.OnClickListener() {
	        	public void onClick(View v) {
	        		
	        		String alumno =  edAlumno.getText().toString();
	        		String tlf 	  =  edTlf.getText().toString();
	        		String curso 	= (String) s.getSelectedItem();
	        		
	        	    addBDAlumno (alumno,tlf,curso);
	        		
	        	}
	        });
	 }
	 
	 
	public void addBDAlumno (String alumno,String tlf,String curso){
	
		if ((alumno.length()!=0)& (tlf.length()!=0)){ 
		 AdaptadorBD  db = new AdaptadorBD (this);

		  db.openEscritura();
	     db.insertarAlumno(alumno,curso,tlf);
	     db.close();

	     Toast.makeText (this,"Almacenamiento base de datos correcta",Toast.LENGTH_SHORT).show();
	     edAlumno.setText("");
 		 edTlf.setText("");
		}
		else Toast.makeText (this,"Todos los campos son obligatorios",Toast.LENGTH_SHORT).show();
	 }

}
