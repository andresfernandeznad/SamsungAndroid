package es.uma.SQL;

public class Alumnos {

	long expediente;
	String Nombre;
	String telefono;
	String curso;
	
	Alumnos (long expediented,String Nombred,String telefonod,String cursod){
		expediente=expediented;
		Nombre=Nombred;
		telefono=telefonod;
		curso=cursod;
	}
	
	Alumnos (String Nombred,String telefonod,String cursod){
		Nombre=Nombred;
		telefono=telefonod;
		curso=cursod;
	}

	Alumnos (){
		expediente=0;
		Nombre=null;
		telefono=null;
		curso=null;
	}
	public void setNombre(String Nombred){
		Nombre=Nombred;
	}
	
	public void setExpediente (long expediented){
		expediente=expediented;
	}
	
	public void setTelefono (String telefonod){
		telefono=telefonod;
	}
	
	public void setCurso(String cursod){
		curso=cursod;
	}
	
	public String getNombre(){
		return Nombre;
	}
	
	public long getExpediente (){
		return expediente;
	}
	
	public String  getTelefono (){
		return telefono;
	}
	
	public String getCurso(){
		return curso;
	}
}
