package es.uma.SQL;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class Consulta extends Activity {
    EditText alumno,tlf;
    Spinner s;
    
    
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.consulta);
	        
	        s = (Spinner) findViewById(R.id.spinnerConsulta);
		    alumno = (EditText)  findViewById(R.id.editTextAlumnoConsulta);
		    tlf = (EditText)  findViewById(R.id.editTextTlfConsulta);
		    final Button botonConsulta= (Button) findViewById(R.id.consultaBoton);
		    final Button botonTlf= (Button) findViewById(R.id.BotonLlamaTlf);
			  
	        AdaptadorBD  db = new AdaptadorBD (this);
			 db.openLectura();
		      
		     	Cursor cursor=db.getTodosAlumnos();

	         		SimpleCursorAdapter adapter2 =
	        		 new SimpleCursorAdapter(this,android.R.layout.simple_spinner_item,cursor,
	        	     new String[] {"telefono"}, new int[] {android.R.id.text1}, 0);


	            	adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	         		s.setAdapter(adapter2);
	         	
	         	int numElementos=cursor.getCount();
	         	if (numElementos==0){
	         		botonConsulta.setEnabled(false);
	         		s.setEnabled(false);
	         		alumno.setEnabled(false);
	         		tlf.setEnabled(false);
	         		Toast.makeText(this, "Base de Datos Vacía. Inserte alumos en Menu Principal", Toast.LENGTH_LONG).show();
	         	}
	       db.close();
	       
	          
	       
	        
	        botonConsulta.setOnClickListener(new ImageButton.OnClickListener() {
	        	public void onClick(View v) {
	        		
	        		Imprime();
	        		botonTlf.setEnabled(true);
	        	}
	        });
		  
	        botonTlf.setOnClickListener(new ImageButton.OnClickListener() {
	        	public void onClick(View v) {
	        
	        		String tlfS=tlf.getText().toString(); 
	    	        Intent intent =new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + tlfS));
	    	        startActivity(intent);	
	    	      }
	        });
	        
	 }
	 
	 
	 public void Imprime (){
		   
			 Cursor expe=(Cursor)s.getSelectedItem();
			 alumno.setText(expe.getString(1));
			 tlf.setText(expe.getString(3));
			 
			
	 }
}
