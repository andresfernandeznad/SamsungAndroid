package com.andresfernandeznadalesgmail.parkingmlaga;

public class Parking {
    private int id;
    private String nombre;
    private String direccion;
    private double latitude;
    private double longitude;
    private String capacidad;
    private String fechaAct;
    private String libres;

    public Parking(int id_, String nombre_) {
        this.id = id_;
        this.nombre = nombre_;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDir(String direccion) {
        this.direccion = direccion;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getFechaAct() {
        return fechaAct;
    }

    public void setFechaAct(String fechaAct) {
        this.fechaAct = fechaAct;
    }

    public String getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(String capacidad) {
        this.capacidad = capacidad;
    }

    public String getLibres() {
        return libres;
    }

    public void setLibres(String libres) {
        this.libres = libres;
    }
}
