package com.andresfernandeznadalesgmail.parkingmlaga;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    static ArrayList<Parking> list_parking = new ArrayList<>();
    CSVReader reader = null;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.textView2);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET}, 10);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 11);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, 12);
        } else {
            Toast.makeText(this,"Permisos Concedidos",Toast.LENGTH_LONG).show();
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button: break;
            case R.id.button2:
                Intent intent = new Intent(getApplicationContext(), MapActivity.class);
                startActivity(intent);
                break;
            case R.id.button3:
                list_parking.clear();
                MyAsyncTask myAsyncTask = new MyAsyncTask();
                myAsyncTask.execute();
                break;
        }
    }

    private class MyAsyncTask extends AsyncTask<Void, Void, CSVReader> {

        @Override
        protected CSVReader doInBackground(Void... voids) {
            CSVReader reader = null;
            String url= "http://datosabiertos.malaga.eu/recursos/aparcamientos/ocupappublicosmun/ocupappublicosmun.csv";
            try {
                URL stockURL = new URL(url);
                BufferedReader in =
                        new BufferedReader(new InputStreamReader(stockURL.openStream()));
                reader = new CSVReader(in);
            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(), "Error al obtener URL", Toast.LENGTH_SHORT).show();
            }
            return reader;
        }

        @Override
        protected void onPostExecute(CSVReader reader) {
            String [] nextLine;
            boolean cabecera = true;
            Parking parking;
            try {
                while ((nextLine = reader.readNext()) != null) {
                    for (int i =  0; i < nextLine.length; i++) {
                        Log.d("CSV",  "Número " + i + " Contenido-> " + nextLine[i]);
                    }
                    if (cabecera) cabecera=false;
                    else{
                        parking = new Parking(Integer.parseInt(nextLine[0]),nextLine[1]);
                        parking.setDir(nextLine[2]);
                        parking.setLatitude(Double.parseDouble(nextLine[5]));
                        parking.setLongitude(Double.parseDouble(nextLine[6]));
                        parking.setCapacidad(nextLine[8]);
                        parking.setFechaAct(nextLine[10]);
                        parking.setLibres(nextLine[11]);
                        list_parking.add(parking);
                    }
                }
            } catch (Exception e){
                Toast.makeText(getApplicationContext(), "Error al cargar", Toast.LENGTH_SHORT).show();
            }
            tv.setText(list_parking.get(7).getFechaAct());
        }
    }
}
