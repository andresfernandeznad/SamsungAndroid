package com.andresfernandeznadalesgmail.parkingmlaga;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap mapa;
    ListView lv;
    Location loc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        MiAdapter miAdapter = new MiAdapter(this, MainActivity.list_parking, R.layout.listview);
        lv = findViewById(R.id.listView);
        lv.setAdapter(miAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Parking parking = (Parking) parent.getItemAtPosition(position);
                // Parking parking = new Parking(((Parking)parent.getItemAtPosition(position)).getId(),((Parking)parent.getItemAtPosition(position)).getNombre());
                LatLng latLng = new LatLng(parking.getLatitude(), parking.getLongitude());
                if (latLng != null) {
                    mapa.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
                    mapa.addMarker(new MarkerOptions()
                            .title(parking.getNombre())
                            .snippet(parking.getLibres() + " / " + parking.getCapacidad())
                            .position(latLng));
                } else {
                    Toast.makeText(getApplicationContext(), "Ubicación no encontrada.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        long minTime = 5000;
        float minDistance = 10;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 11);
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 12);
        }
        Criteria criteria = new Criteria();

        loc = locationManager.getLastKnownLocation(locationManager
                .getBestProvider(criteria, false));
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                //loc = location;
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng greenRay = new LatLng(loc.getLatitude(),loc.getLongitude());
        int zoom = 17;
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(greenRay, zoom));
        mapa = googleMap;
    }

    private class MiAdapter extends BaseAdapter{

        Context ctx;
        ArrayList<Parking> list;
        int resource;

        public MiAdapter(Context ctx, ArrayList<Parking> list, int resource) {
            this.ctx = ctx;
            this.list = list;
            this.resource = resource;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View miVista = null;
            LayoutInflater inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (miVista == null) {
                miVista = inflater.inflate(resource, null);
            } else {
                miVista = convertView;
            }

            TextView id = (TextView) miVista.findViewById(R.id.text_ID);
            TextView nombre = (TextView) miVista.findViewById(R.id.text_Nombre);
            id.setText(""+((Parking)(getItem(position))).getId());
            nombre.setText(((Parking)(getItem(position))).getNombre());
            return miVista;
        }
    }

    public void onClick(View v) {
        Location GreenRay = new Location("Mi ubicación");
        GreenRay.setLatitude(loc.getLatitude());
        GreenRay.setLongitude(loc.getLongitude());
        Log.d("LOCATION", loc.getLatitude() + "");
        String cercano = "";
        float menor = Float.MAX_VALUE;
        for (int i = 1; i < MainActivity.list_parking.size(); i++) {
            if (GreenRay.distanceTo(new Location(MainActivity.list_parking.get(i).getNombre()))< menor) {
                cercano = MainActivity.list_parking.get(i).getNombre();
            }
        }
        Toast.makeText(getApplicationContext(), "El parking más cercano a tu ubicación es " + cercano, Toast.LENGTH_SHORT).show();
    }
}
