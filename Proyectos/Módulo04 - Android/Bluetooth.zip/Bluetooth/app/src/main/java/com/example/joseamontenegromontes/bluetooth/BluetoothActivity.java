package com.example.joseamontenegromontes.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;

public class BluetoothActivity extends AppCompatActivity {
    int REQUEST_ENABLE_BT=1;
    BluetoothAdapter mBluetoothAdapter;

    TextView estadoB;
    ListView paired,newDiscover;
    ArrayAdapter adapterPaired,adapterNew;

    ArrayList<BluetoothDevice> arrayListPairedBluetoothDevices = null;
    ArrayList<BluetoothDevice> arrayListBluetoothDevices = null;
    boolean broadcastRegister=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);


        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Toast.makeText(this,"Dispositivo no soporta bluetooth",Toast.LENGTH_LONG).show();
        }else {

            estadoB = (TextView) findViewById(R.id.estadoText);
            paired = (ListView) findViewById(R.id.listView);
            newDiscover = (ListView) findViewById(R.id.listView2);
            arrayListPairedBluetoothDevices = new ArrayList<BluetoothDevice>();
            arrayListBluetoothDevices = new ArrayList<BluetoothDevice>();

            final ArrayList<String> list = new ArrayList<>();
            adapterPaired = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
            paired.setAdapter(adapterPaired);

            final ArrayList<String> listNew = new ArrayList<>();
            adapterNew = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listNew);
            newDiscover.setAdapter(adapterNew);

            paired.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override

                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Toast.makeText(getApplicationContext(),
                            "Pulsado " + i + " " + adapterView.getItemAtPosition(i), Toast.LENGTH_LONG).show();

                    BluetoothDevice device = arrayListPairedBluetoothDevices.get(i);

                    unpairDevice(device);
                    arrayListPairedBluetoothDevices.remove(i);

                    adapterPaired.clear();

                    for (BluetoothDevice newDevice : arrayListPairedBluetoothDevices) {
                        adapterPaired.add(newDevice.getName() + "\n" + newDevice.getAddress());
                    }


                }
            });

            newDiscover.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Toast.makeText(getApplicationContext(),
                            "Pulsado " + i + " " + adapterView.getItemAtPosition(i), Toast.LENGTH_LONG).show();

                    BluetoothDevice device = arrayListBluetoothDevices.get(i);
                    pairDevice(device);

                    arrayListBluetoothDevices.remove(i);
                    adapterNew.clear();

                    for (BluetoothDevice newDevice : arrayListBluetoothDevices) {
                        adapterNew.add(newDevice.getName() + "\n" + newDevice.getAddress());
                    }

                }
            });


            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            } else {
                estadoB.setText("Conectado");
                paired();
            }


            // Registro BroadCastReceiver
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
            registerReceiver(mReceiver, filter);

            broadcastRegister = true; // Para saber onDestroy
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (broadcastRegister) unregisterReceiver(mReceiver);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_ENABLE_BT) {

            if (resultCode == RESULT_OK) {
                estadoB.setText("Conectado");
                Log.v("Blueetooth","Usuario activo el Bluetooth");
                paired();
            }
            else {
                estadoB.setText("No Conectado");
                Log.v("Blueetooth","Usuario NO activo el Bluetooth");
            }
        }
    }

    private void paired(){
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                adapterPaired.add(device.getName() + "\n" + device.getAddress());
                arrayListPairedBluetoothDevices.add(device);
            }
        }
    }

   ///

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        adapterPaired.clear();
                        adapterNew.clear();
                        estadoB.setText("Bluetooth off");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        estadoB.setText("Turning Bluetooth off...");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        estadoB.setText("Bluetooth on"); paired();
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        estadoB.setText("Turning Bluetooth on...");
                        break;
                }
            }

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                adapterNew.add(device.getName() + "\n" + device.getAddress());
                arrayListBluetoothDevices.add(device);
            }

            if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                final int state        = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR);
                final int prevState    = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, BluetoothDevice.ERROR);

                if (state == BluetoothDevice.BOND_BONDED && prevState == BluetoothDevice.BOND_BONDING) {
                    Toast.makeText(getApplicationContext(),"Paired",Toast.LENGTH_LONG).show();
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    adapterPaired.add(device.getName() + "\n" + device.getAddress());
                    arrayListPairedBluetoothDevices.add(device);

                } else if (state == BluetoothDevice.BOND_NONE && prevState == BluetoothDevice.BOND_BONDED){
                    Toast.makeText(getApplicationContext(),"Unpaired",Toast.LENGTH_LONG).show();

                }

            }
        }
    };


    public void onClick(View view){
        final boolean b = mBluetoothAdapter.startDiscovery();
        Log.d("Bluetooh","Discovery resultado: "+b);
    }


    private void pairDevice(BluetoothDevice device) {
        try {
            Method method = device.getClass().getMethod("createBond", (Class[]) null);
            method.invoke(device, (Object[]) null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void unpairDevice(BluetoothDevice device) {
        try {
            Method method = device.getClass().getMethod("removeBond", (Class[]) null);
            method.invoke(device, (Object[]) null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
