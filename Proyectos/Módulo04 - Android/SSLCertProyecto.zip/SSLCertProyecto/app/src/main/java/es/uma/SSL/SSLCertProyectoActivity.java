package es.uma.SSL;


import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.LinkedList;


import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SSLCertProyectoActivity extends AppCompatActivity {
	String host;
	Context context;
	 Spinner spinnerCert;
    EditText ServerName;
    TextView Info,Certs;
	 @Override



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        context = getApplicationContext();
        
         Button ConectarB= (Button) findViewById(R.id.ConectarBoton);
         ServerName= (EditText) findViewById(R.id.serverName);
         Info= (TextView) findViewById(R.id.statusText);
         Certs= (TextView) findViewById(R.id.textResultado);

         spinnerCert= (Spinner) findViewById(R.id.spinner1);

         spinnerCert.setVisibility(View.INVISIBLE);

        ConectarB.setOnClickListener(new Button.OnClickListener() {
        	public void onClick(View v) {
        		
        		if(ServerName.getText().length()==0){
        			Toast.makeText(context, "Longitud del Servidor no valida", Toast.LENGTH_LONG).show();
        		}
        		else{
	        		host= ServerName.getText().toString();
	        		Info.setText(host);
	        	
	        		new SSLTask().execute();

	        	 }
    		}
        }
        );
        
    }

    private class SSLTask extends AsyncTask<Void,Void,Void> {

        Certificate[] peerCertificates; //Certificados que obtengo conexiOn
        public X509Certificate[] serverCertificates=null;

        int numCert=0;	//Numeros Certificados Obtenidos
        private int port=443;
        long init,fin;

        protected Void doInBackground(Void... voids) {
            try {
                init=System.currentTimeMillis();
                SSLSocketFactory factory = HttpsURLConnection.getDefaultSSLSocketFactory();
                SSLSocket socket = (SSLSocket)factory.createSocket(host, port);

                HandshakeyCertificacion(socket);
                socket.close();
                fin=System.currentTimeMillis();
            } catch(IOException e) {
                Log.i("SSL", "Certificados  "+e);
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            Info.setText("Certificados "+numCert+ " en: "+(fin-init)+" msdos. ");

            if (numCert>0){
                spinnerCert.setVisibility(View.VISIBLE);

                final LinkedList<X509Cert> certificados = new LinkedList<X509Cert>();

                for (int i = 0; i < numCert; ++i) {
                        certificados.add(new X509Cert(serverCertificates[i]));
                }


                ArrayAdapter<X509Cert> spinner_adapter =
                        new ArrayAdapter<X509Cert> (SSLCertProyectoActivity.this, android.R.layout.simple_spinner_item, certificados);
                spinner_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCert.setAdapter(spinner_adapter);

                spinnerCert.setOnItemSelectedListener(
                        new AdapterView.OnItemSelectedListener() {
                            public void onItemSelected(AdapterView<?> parent,
                                                       android.view.View v, int position, long id) {
                                Certs.setText(certificados.get(position).Imprimir());
                            }

                            public void onNothingSelected(AdapterView<?> parent) {
                                Certs.setText("");
                            }
                        });
            }
        }

        public void HandshakeyCertificacion(SSLSocket sslSocket)
                throws IOException {

            // Hacemos el Handshake
            try {
                sslSocket.startHandshake();
            } catch (IOException e) {
                Log.e("SSLHandshake", e.getMessage());
            }

            SSLSession sesionSSL=sslSocket.getSession();
            if (sesionSSL!=null) {

                // obtener los certificados
                peerCertificates = sesionSSL.getPeerCertificates();


                if (peerCertificates != null) {

                    numCert = peerCertificates.length;

                    if (numCert > 0) {
                        serverCertificates = new X509Certificate[numCert];
                        Log.i("SSL", "Hemos encontrado " + numCert + " Certificados.");

                        for (int i = 0; i < peerCertificates.length; ++i) {
                            serverCertificates[i] = (X509Certificate) (peerCertificates[i]);
                            Log.i("SSL", "Certificado: " + serverCertificates[i].toString());
                        }
                    }
                    else{
                        Log.e("SSLHandshake", "Certificados <=0 " + numCert);
                    }
                }
                 else {
                    Log.e("SSLHandshake", "No hay certificados");
                }
            }
        }


    }


}