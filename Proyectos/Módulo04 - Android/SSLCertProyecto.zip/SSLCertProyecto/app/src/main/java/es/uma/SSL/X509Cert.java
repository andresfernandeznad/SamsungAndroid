package es.uma.SSL;

import java.security.cert.X509Certificate;

public class X509Cert {

	X509Certificate cert;
	
	
	X509Cert (X509Certificate crt){
		cert=crt;
	}
	
	public String toString(){
		return cert.getSubjectDN().getName();
	}
	
	public String Imprimir(){
		String certS="Certificado X509 V"+ cert.getVersion() +"\n\n";
		certS=certS.concat("Usuario: \n"+cert.getSubjectDN().getName()+" \n\n");
		certS=certS.concat("Emisor: \n"+cert.getIssuerDN().getName()+" \n\n");
		certS=certS.concat("Numero de Serie: \n"+cert.getSerialNumber()+" \n\n");
		certS=certS.concat("Validez: \nDesde "+cert.getNotBefore()+"\n"+"Hasta "+cert.getNotAfter());
		
		return certS;
	}



}
