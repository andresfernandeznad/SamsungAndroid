package com.andresfernandeznadalesgmail.repasogridview;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    static ArrayList<Integer> listaNum = new ArrayList<>();
    EditText editText;
    //Set<String> lista = new HashSet<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText2);
    }

    public void onClick(View v) {
        if (editText.getText().length() > 0) {
            if (Integer.parseInt(editText.getText().toString()) >= 1 && Integer.parseInt(editText.getText().toString()) <= 195) {
                Intent intent = new Intent(this, Main2Activity.class);
                intent.putExtra("num", Integer.parseInt(editText.getText().toString()));
                intent.putExtra("listaNum", listaNum);
                startActivityForResult(intent, 1);
                listaNum.add(Integer.parseInt(editText.getText().toString()));
                editText.setText("");
            } else {
                Toast.makeText(this, "Introduce un número válido", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /*private String guardar() {
        String salida="";
        for (Integer num : listaNum) {
            salida += num + ",";
        }
        return salida;
    }

    private void save() {
        SharedPreferences settings = getSharedPreferences("imagenes", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putStringSet("setString", lista);
        editor.commit();
    }*/
}
