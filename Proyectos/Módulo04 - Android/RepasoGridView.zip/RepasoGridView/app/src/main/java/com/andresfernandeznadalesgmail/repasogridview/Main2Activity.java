package com.andresfernandeznadalesgmail.repasogridview;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    GridView gv;
    int num;
    static ArrayList<Bitmap> banderas = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        gv = findViewById(R.id.gridView);
        Intent intent = getIntent();
        if (intent != null) {
            num = intent.getIntExtra("num", 0);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, 10);
        }
        MyAsyncTask asyncTask = new MyAsyncTask();
        asyncTask.execute();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,@NonNull int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                break;
        }
    }

    private class MyAsyncTask extends AsyncTask<Void,Void,Void> {

        Bitmap bm;
        MiAdapter adapter;

        @Override
        protected Void doInBackground(Void... voids) {
            URL url = null; //http://192.168.0.160:8080/image.php?n=2
            try {
                url = new URL("http://192.168.1.72:8080/image.php?n=" + num);
                InputStream is = url.openStream();
                bm = BitmapFactory.decodeStream(is);
            } catch (IOException e) {
                e.printStackTrace();
            }
            banderas.add(bm);
            return null;
        }

        @Override
        protected void onPostExecute(Void Void) {
            adapter = new MiAdapter(getApplicationContext(), R.layout.gridview, banderas);
            gv.setAdapter(adapter);
        }
    }

    private class MiAdapter extends BaseAdapter {

        Context ctx;
        int recursoIDlayout;
        ArrayList datos;

        public MiAdapter(Context ctx, int recursoIDlayout, ArrayList datos) {
            this.ctx = ctx;
            this.recursoIDlayout = recursoIDlayout;
            this.datos = datos;
        }

        @Override
        public int getCount() {
            return banderas.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View vista = null;
            LayoutInflater layoutInflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            if (convertView == null) {
                vista = layoutInflater.inflate(recursoIDlayout, null);
            } else {
                vista = (View) convertView;
            }
            ImageView iv = vista.findViewById(R.id.imageView);
            iv.setImageBitmap((Bitmap) datos.get(position));
            return vista;
        }
    }
}
