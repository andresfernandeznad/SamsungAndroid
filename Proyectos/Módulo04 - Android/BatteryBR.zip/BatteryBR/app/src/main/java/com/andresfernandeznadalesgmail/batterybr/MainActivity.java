package com.andresfernandeznadalesgmail.batterybr;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.display.DisplayManager;
import android.os.BatteryManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.Display;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    TextView txt, txt1, txt2;
    ReceptorIntentPhone bateria;
    //ReceptorPantalla pantalla;
    int pantallaOn = 0, pantallaOf = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.Bateria);
        txt1 = (TextView) findViewById(R.id.textView);
        txt2 = (TextView) findViewById(R.id.textView2);
        bateria = new ReceptorIntentPhone();
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED); //Crea un filtro de un intent especifico cuando cambia algo del sistema.
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
        registerReceiver(bateria, filter);
        //registerReceiver(pantalla, filerCargardor);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(bateria);
    }
    private class ReceptorIntentPhone extends BroadcastReceiver{ //Clase que se encarga de coger esos elementos e implementos el onReceive

        @RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)) {
                int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL;
                if (isCharging) {
                    int chargePlug = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
                    boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
                    boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
                    if (usbCharge) txt.setText("Cargando por USB...");
                    if (acCharge) txt.setText("Cargando red Eléctrica...");
                } else txt.setText("No Carga...");
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                String msg = txt.getText().toString();
                msg = msg.concat(" nivel batería " + level);
                txt.setText(msg);
            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                pantallaOf++;
                txt2.setText("Pantalla apagada " + pantallaOf);
            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                pantallaOn++;
                txt1.setText("Pantalla encendida " + pantallaOn);
            } else if (intent.getAction().equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
                
            }
        }
    }

    /*private class ReceptorPantalla extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            //....todo
        }
    }*/
}
