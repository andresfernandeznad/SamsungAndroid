package com.andresfernandeznadalesgmail.intentfilter;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    TextView url;

    WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        url = findViewById(R.id.textView2);

        Uri data=getIntent().getData();

        url.setText(data.toString());

        String prueba = data.toString();

        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET);

        if (permission == PackageManager.PERMISSION_GRANTED) {

        } else {
            String [] permisos = {Manifest.permission.INTERNET};
            ActivityCompat.requestPermissions(this, permisos, 1);
        }
        web = findViewById(R.id.vistaWeb);
        web.loadUrl(url.getText().toString());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("Actividad:Call", "Permiso Concedido");

                }
            }
        }
    }
}
