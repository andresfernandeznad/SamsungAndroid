package com.andresfernandeznadalesgmail.intentfilter;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.AlarmClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!Intent.ACTION_MAIN.equals(getIntent().getAction()) ){
            Uri data=getIntent().getData();
            if (data==null){
                Toast.makeText(this, "Sin datos", Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this, data.toString(), Toast.LENGTH_LONG).show()
                ;
            }
        }

        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.SET_ALARM);

        if (permission == PackageManager.PERMISSION_GRANTED) {
            Log.d("hola", "fasdfa");
        } else {
            String [] permisos = {Manifest.permission.SET_ALARM};
            ActivityCompat.requestPermissions(this, permisos, 2);
        }
    }
    public void ViewFiltro (View V){
        String link="http://www.marca.com/tenis.html";//Crea el link
        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(link)); //Lanzo algo para que el sistema busque quien puede abrirlo
        PackageManager pm = getPackageManager();
        List<ResolveInfo> infoList = pm.queryIntentActivities(intent,PackageManager.MATCH_DEFAULT_ONLY);
        int num = infoList.size();
        Log.d("Intent", "Hemos encontrado: ");
        for (int i = 0; i < num; i++) {
            Log.d("Intent", infoList.get(i).activityInfo.name);
        }
        if (num > 0) startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 2: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("Actividad:Call", "Permiso Concedido");
                    Log.d("hola", "fasdfa");
                }
            }
        }
    }


    public void ViewNoFiltro (View V){
        /*String link="http://www.uma.es";
        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(link));
        startActivity(intent);*/

            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "SDfas")
                    .putExtra(AlarmClock.EXTRA_HOUR, 17)
                    .putExtra(AlarmClock.EXTRA_MINUTES, 45);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }

    }
}
