package com.andresfernandeznadalesgmail.examenandroid;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                String num = tam.getText().toString();
                if (num.matches("[0-9]+")) {
                    tamArray = Integer.parseInt(num);
                    A = new float[tamArray];
                    B = new float[tamArray];
                    C = new float[tamArray];
                    Random rand = new Random();
                    for (int i = 0; i < A.length; i++) {
                        A[i] = (float)(rand.nextInt(200)/100.0)-1;
                        B[i] = (float)(rand.nextInt(200)/100.0)-1;
                    }
                } else {
                    Toast.makeText(this, "Not a number", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.button2:
                if (A == null) {
                    Toast.makeText(this, "Arrays no inicializados.", Toast.LENGTH_LONG).show();
                } else {
                    nat = checkBoxNat.isChecked();
                    par = checkBoxPar.isChecked();
                    numThreads = Integer.parseInt(numTh.getText().toString());
                    new myAsyncTask().execute();
                }
        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        // Save instance-specific state
        outState.putInt("array_size", tamArray);
        outState.putInt("numTh", numThreads);
        outState.putString("tiempoEje", tiempo.getText().toString());
        super.onSaveInstanceState(outState);
    }

    private class myAsyncTask extends AsyncTask<Void, Void, Void> {
        long t0, t1;
        @Override
        protected Void doInBackground(Void... v) {
            t0 = System.nanoTime();
            if (nat && par) {
                calculoThreads(A, B, C, tamArray, numThreads);
            } else {
                if (par) {
                    int numTask = numThreads * 4;
                    ExecutorService executor = Executors.newFixedThreadPool(numThreads);

                    for (int i = 0; i < numTask; i++) {
                        executor.execute(new myTask(i, numTask));
                    }
                    executor.shutdown();
                    try {
                        executor.awaitTermination(10, TimeUnit.MINUTES);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else if (nat) {
                    calculo(A, B, C, tamArray);
                } else {
                    for (int i = 0; i < C.length; i++) {
                        C[i] = A[i] * B[i];
                    }
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void voids) {
            t1 = System.nanoTime();
            tiempo.setText(((t1 - t0) / 1000000.0) + " ms");
        }
    }

    public class myTask implements Runnable {
        private int id;
        private int nTask;
        myTask(int id, int nTask) {
            this.id = id;
            this.nTask = nTask;
        }
        @Override
        public void run() {
            int ini = (this.id * tamArray)/this.nTask;
            int fin = ((this.id + 1) * tamArray)/this.nTask;
            for (int i = ini; i < fin; i++) {
                C[i] = A[i] * B[i];
            }
        }
    }

    public native void calculo(float [] A, float [] B, float[] C, int tamArray);

    public native void calculoThreads(float [] A, float [] B, float[] C, int tamArray, int numThreads);

    Button btnInit;
    Button btnComp;
    float [] A, B, C;
    int tamArray;
    int numThreads;
    static boolean par, nat;
    EditText tam, numTh;
    TextView tiempo;
    CheckBox checkBoxPar, checkBoxNat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tam = findViewById(R.id.editText3);
        numTh = findViewById(R.id.editText4);
        tiempo = findViewById(R.id.textView4);
        checkBoxPar = findViewById(R.id.checkBox);
        checkBoxNat = findViewById(R.id.checkBox2);
        btnInit = findViewById(R.id.button);
        btnInit.setOnClickListener(this);
        btnComp = findViewById(R.id.button2);
        btnComp.setOnClickListener(this);
        if (savedInstanceState != null) {
            tamArray = savedInstanceState.getInt("array_size");
            numThreads = savedInstanceState.getInt("numTh");
            tiempo.setText(savedInstanceState.getString("tiempoEje"));
        }
    }
}
