#include <jni.h>
#include <string>
#include <vector>
#include <thread>

using namespace std;
extern "C"
JNIEXPORT void JNICALL
Java_com_andresfernandeznadalesgmail_examenandroid_MainActivity_calculo(JNIEnv *env,
                                                                        jobject instance,
                                                                        jfloatArray A_,
                                                                        jfloatArray B_,
                                                                        jfloatArray C_,
                                                                        jint tamArray) {
    jfloat *A = env->GetFloatArrayElements(A_, NULL);
    jfloat *B = env->GetFloatArrayElements(B_, NULL);
    jfloat *C = env->GetFloatArrayElements(C_, NULL);

    for (int i = 0; i < tamArray; i++) {
        C[i] = A[i] * B[i];
    }

    env->ReleaseFloatArrayElements(A_, A, 0);
    env->ReleaseFloatArrayElements(B_, B, 0);
    env->ReleaseFloatArrayElements(C_, C, 0);
}

void calcula(int id, int nth, int tam, float *A, float * B, float * C) {
    for (int i = id*tam/nth; i < (id + 1)*tam/nth; ++i) {
        C[i] = A[i] * B[i];
    }
}
extern "C"
JNIEXPORT void JNICALL
Java_com_andresfernandeznadalesgmail_examenandroid_MainActivity_calculoThreads(JNIEnv *env,
                                                                               jobject instance,
                                                                               jfloatArray A_,
                                                                               jfloatArray B_,
                                                                               jfloatArray C_,
                                                                               jint tamArray,
                                                                               jint numThreads) {
    jfloat *A = env->GetFloatArrayElements(A_, NULL);
    jfloat *B = env->GetFloatArrayElements(B_, NULL);
    jfloat *C = env->GetFloatArrayElements(C_, NULL);

    vector<thread> t;
    for (int i = 0; i < numThreads; ++i) {
        t.push_back(thread(calcula,i, numThreads, tamArray, A, B, C));
    }
    for (auto &th: t) {
        th.join();
    }

    env->ReleaseFloatArrayElements(A_, A, 0);
    env->ReleaseFloatArrayElements(B_, B, 0);
    env->ReleaseFloatArrayElements(C_, C, 0);
}